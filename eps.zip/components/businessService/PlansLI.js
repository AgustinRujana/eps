import { useEffect } from 'react';

export default function PlansLI({ content }) {
  useEffect(() => {}, []);
  return <li></li>;
}
